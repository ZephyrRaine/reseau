﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;
using UnityEngine.Networking.NetworkSystem;
using Completed;
public class GameMessage : MessageBase
{
    public int xDir;
    public int yDir;
}

public class StartMessage : MessageBase
{
    public int seed;
}

public class Network : NetworkManager
{
    const short START_MSG = 1010;
    const short GAME_MSG = 1012;

    public Completed.Player[] players;

    int networkSeed;

    NetworkConnection m_Connection;


    public void Start()
    {
        GameManager.instance.NM = this;
    }
    public override void OnStartHost()
    {
        networkSeed = UnityEngine.Random.Range(int.MinValue, int.MaxValue);
        Debug.Log(networkSeed);
        UnityEngine.Random.InitState(networkSeed);
        GameManager.instance.InitLol();
        GameManager.instance.other = players[1];
    }

    public override void OnServerConnect(NetworkConnection conn)
    {
        Debug.Log("OnServerConnect");
        RegisterConnection(conn);
        SendStartMsg();
    }

    
    public override void OnClientConnect(NetworkConnection conn)
    {
        Debug.Log("OnClientConnect");
        RegisterConnection(conn);
    }


    public void RegisterConnection(NetworkConnection connection)
    {
        m_Connection = connection;
        m_Connection.RegisterHandler(START_MSG, OnStartMsg);
        m_Connection.RegisterHandler(GAME_MSG, OnGameMsg);
    }


    void OnGUI()
    {
        if(GUI.Button(new Rect(10,200,50,30), "Start"))
            SendStartMsg();    

        if(GUI.Button(new Rect(10,240,50,30), "Game"))
            SendGameMsg(0,0);
    }

    void SendStartMsg()
    { 
       StartMessage start = new StartMessage();
       start.seed = networkSeed;
       m_Connection.Send(START_MSG, start);
    }

    public void SendGameMsg(int xDir, int yDir)
    {
       var msg = new GameMessage();
       msg.xDir = xDir;
       msg.yDir = yDir;
       m_Connection.Send(GAME_MSG, msg);
    }

    void OnStartMsg(NetworkMessage networkMessage)
    {
        var message = networkMessage.ReadMessage<StartMessage>();
        UnityEngine.Random.InitState(message.seed);
        GameManager.instance.InitLol();
        Debug.Log("SEED IS : " + message.seed);
        GameManager.instance.other = players[0];
    }
    void OnGameMsg(NetworkMessage networkMessage)
    {
        var message = networkMessage.ReadMessage<GameMessage>();
        Debug.Log("received OnGameMsg " + message);
        Completed.GameManager.instance.OtherMoved(message.xDir, message.yDir);
    }
    void OnEndMsg(NetworkMessage networkMessage)
    {
        // var message = networkMessage.ReadMessage<EndMessage>();
        // Debug.Log("received OnEndMsg " + message);
    }
}